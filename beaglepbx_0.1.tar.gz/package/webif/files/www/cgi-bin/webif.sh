#!/bin/sh
exec ./webif/info.sh
